from dotenv import load_dotenv
load_dotenv()

import os
import json
import logging
from pathlib import Path
from typing import Dict, Optional, List

from openai import OpenAI, OpenAIError, APIError
from jsonschema import validate, ValidationError

from models.types import (
    DraftInput,
    RecommendationResponse,
    BuildOptionsRequest,
    BuildOptionsResponse,
    DetailedBuildRequest,
    DetailedBuildResponse,
    BuildVariant
)
from services.logic import generate_recommendation, fallback_build_options, fallback_detailed_build

# === Константы ===
PROMPT_PATH = Path(__file__).resolve().parent.parent / "prompts" / "ai_prompt.txt"
SCHEMA_PATH = Path(__file__).resolve().parent.parent / "models" / "openai_response_schema.json"

MODEL = os.getenv("OPENAI_MODEL", "gpt-4")
TEMPERATURE = float(os.getenv("OPENAI_TEMP", "0.7"))
MAX_TOKENS = int(os.getenv("OPENAI_MAX_TOKENS", "2000"))
API_KEY = os.getenv("OPENAI_API_KEY")

client: Optional[OpenAI] = None

# === Инициализация ===

def is_valid_api_key(key: Optional[str]) -> bool:
    return key and key.startswith("sk-") and len(key) > 20

def init_openai_client() -> Optional[OpenAI]:
    if not is_valid_api_key(API_KEY):
        logging.warning("❌ OPENAI_API_KEY не установлен или некорректен.")
        return None
    return OpenAI(api_key=API_KEY)

def load_base_prompt() -> str:
    if not PROMPT_PATH.exists():
        raise FileNotFoundError(f"Файл промпта не найден: {PROMPT_PATH}")
    with PROMPT_PATH.open("r", encoding="utf-8") as f:
        return f.read().strip()

def validate_openai_json(data: Dict) -> bool:
    try:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            schema = json.load(f)
        validate(instance=data, schema=schema)
        return True
    except ValidationError as ve:
        logging.warning("⚠️ Ответ OpenAI не прошёл валидацию схемы: %s", ve.message)
        return False
    except Exception as e:
        logging.error("💥 Ошибка при валидации схемы: %s", e)
        return False

# === Формирование запроса ===

def format_draft_input(draft: DraftInput) -> Dict:
    return {
        "role": draft.user_role,
        "user_hero": draft.user_hero,
        "allies": draft.ally_heroes or [],
        "enemies": draft.enemy_heroes or [],
    }

def build_user_prompt(draft: DraftInput, input_data: Dict) -> str:
    base = (
        f"Вот входные данные драфта:\n{input_data}\n"
        "Проанализируй выбранного героя и его роль в матче. "
        "Подбери оптимальный стиль игры (маг, контроль, пуш и т.п.).\n"
        "Сгенерируй от 2 до 4 билдов, каждый из которых содержит:\n"
        "- name, description, winrate_score\n"
        "- build, starting_items, skill_build, talents\n"
        "- game_plan, item_notes\n"
        "Добавь ключи: recommended_aspect, suggested_heroes, lane_opponents, build_easy, build_even, build_hard, warnings, source\n"
        "Ответ строго в JSON, валидный по схеме."
    )
    if draft.user_hero:
        return base + "\nПользователь уже выбрал героя — не предлагай других."
    return base + "\nЕсли герой не выбран — предложи наиболее подходящих в suggested_heroes."

# === /recommend ===

def generate_openai_recommendation(draft: DraftInput) -> RecommendationResponse:
    global client
    if not client:
        client = init_openai_client()

    if not client:
        logging.warning("⚠️ OpenAI client не инициализирован. Используется fallback логика.")
        return generate_recommendation(draft)

    prompt = load_base_prompt()
    input_data = format_draft_input(draft)
    user_prompt = build_user_prompt(draft, input_data)

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
        )

        content = response.choices[0].message.content.strip()
        logging.info("📩 Ответ OpenAI: %s", content[:500])

        parsed = json.loads(content)

        if not validate_openai_json(parsed):
            logging.warning("❌ Ответ от OpenAI не соответствует схеме. Используется fallback.")
            return generate_recommendation(draft)

        return RecommendationResponse(**parsed)

    except Exception as e:
        logging.exception("💀 Ошибка при генерации OpenAI ответа.")
        return generate_recommendation(draft)

# === /builds/options ===

def generate_build_options(
    hero: str,
    role: str,
    aspect: str,
    enemy_lane_heroes: List[str]
) -> List[BuildVariant]:
    global client
    if not client:
        client = init_openai_client()

    if not client:
        logging.warning("⚠️ Используется fallback генерация билдов.")
        return fallback_build_options(hero, role, aspect, enemy_lane_heroes)

    user_prompt = (
        f"Герой: {hero}\n"
        f"Роль: {role}\n"
        f"Аспект: {aspect}\n"
        f"Враги на линии: {enemy_lane_heroes}\n\n"
        "Сгенерируй 3-5 билдов (BuildVariant), каждый из которых имеет поля:\n"
        "- id (например 'build_easy', 'build_mage', 'build_push')\n"
        "- label (человекочитаемое название: 'Маг', 'Пуш', 'Физический урон')\n"
        "- description (пояснение, почему билд подходит)\n"
        "Ответ строго в виде JSON-массива."
    )

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": user_prompt}],
            temperature=TEMPERATURE,
            max_tokens=1000
        )

        raw = response.choices[0].message.content.strip()
        parsed = json.loads(raw)

        return [BuildVariant(**b) for b in parsed]

    except Exception as e:
        logging.exception("💥 Ошибка генерации build options")
        return fallback_build_options(hero, role, aspect, enemy_lane_heroes)

# === /builds/detailed ===

def generate_detailed_build(
    hero: str,
    role: str,
    aspect: str,
    selected_build_id: str,
    enemy_heroes: List[str],
    ally_heroes: List[str]
) -> DetailedBuildResponse:
    global client
    if not client:
        client = init_openai_client()

    if not client:
        logging.warning("⚠️ Используется fallback логика detailed build.")
        return fallback_detailed_build(hero, role, aspect, selected_build_id, enemy_heroes, ally_heroes)

    user_prompt = (
        f"Герой: {hero}, Роль: {role}, Аспект: {aspect}\n"
        f"Выбранный билд: {selected_build_id}\n"
        f"Враги: {enemy_heroes}\n"
        f"Союзники: {ally_heroes}\n\n"
        "Сгенерируй подробный билд с полями:\n"
        "- starting_items, early_game_items, mid_game_items, late_game_items, situational_items\n"
        "- skill_build (из 'Q', 'W', 'E', 'R', 'Stats')\n"
        "- talents (10, 15, 20, 25)\n"
        "- game_plan (early_game, mid_game, late_game)\n"
        "- item_explanations (ключ — предмет, значение — зачем он)\n"
        "- warnings (массив строк)\n"
        "- source (всегда 'openai')\n"
        "Ответ строго в JSON."
    )

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": user_prompt}],
            temperature=TEMPERATURE,
            max_tokens=1500
        )

        raw = response.choices[0].message.content.strip()
        parsed = json.loads(raw)
        parsed["source"] = "openai"
        return DetailedBuildResponse(**parsed)

    except Exception as e:
        logging.exception("💥 Ошибка генерации detailed build")
        return fallback_detailed_build(hero, role, aspect, selected_build_id, enemy_heroes, ally_heroes)
